1. This program is built with JDK-22
2. There are 2 packages which contains the solutions for 2 problems
3. Test programs are provided separately under test