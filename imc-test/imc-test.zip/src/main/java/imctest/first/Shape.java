package main.java.imctest.first;

public interface Shape {

    void accept(ShapeVisitor shapeVisitor);

}
