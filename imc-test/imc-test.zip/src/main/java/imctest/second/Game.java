package main.java.imctest.second;

public interface Game {

    void start();

    void end();
}
