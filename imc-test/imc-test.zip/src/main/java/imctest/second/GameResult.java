package main.java.imctest.second;

public enum GameResult {
    WIN,
    LOST,
    DRAW;
}
