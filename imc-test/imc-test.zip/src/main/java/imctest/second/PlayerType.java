package main.java.imctest.second;

public enum PlayerType {

    RealPLayer,
    Computer,
    Nobody;
}
