package main.java.imctest.second;

public enum PRSInputState {

    Paper,
    Rock,
    Scissor,
    Invalid;
}
