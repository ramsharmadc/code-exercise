package main.test.second;

import main.java.imctest.second.Game;
import main.java.imctest.second.PaperRockScissor;

public class TestProgram {

    public static void main(String[] args) {

        Game newGame = new PaperRockScissor();
        newGame.start();

    }
}
